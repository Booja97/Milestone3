package com.example.stockspring.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.stockspring.dao.UserDao;
import com.example.stockspring.model.user;




@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;

	public user registerUser(user user) throws Exception {
		return userDao.registerUser(user);

	}

	
	public user updateUser(user user) throws Exception {
		return userDao.updateUser(user);
	
	}

}
