package com.example.stockspring.service;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;

import com.example.stockspring.model.user;

public interface UserService {
	 public user registerUser(user user) throws Exception;
	 public user updateUser(user user)throws Exception;
	 
}
