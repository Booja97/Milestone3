package com.example.stockspring.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.stockspring.model.IpoPlanned;



public interface IPOPlanedDao extends JpaRepository<IpoPlanned, Integer>{
    static List<IpoPlanned> findByCompanyCode(int companyCode) {
		// TODO Auto-generated method stub
		return null;
	}
}
