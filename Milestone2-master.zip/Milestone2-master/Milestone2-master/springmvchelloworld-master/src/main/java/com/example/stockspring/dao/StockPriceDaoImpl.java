/*package com.premium.stc.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.premium.stc.model.StockPrice;
@Repository
public class StockPriceDaoImpl implements StockPriceDao {

	
	public StockPrice insertStock(StockPrice stock) {
		// TODO Auto-generated method stub
		return null;
	}


	public StockPrice updateStock(StockPrice stock) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public List<StockPrice> getStockPrice() {
		// TODO Auto-generated method stub
		return null;
	}

}*/
