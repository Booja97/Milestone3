package com.example.stockspring.dao;

import com.example.stockspring.model.user;

public interface UserDao {
	 public user registerUser(user user) throws Exception;
	 public user updateUser(user user)throws Exception;
	 
}
